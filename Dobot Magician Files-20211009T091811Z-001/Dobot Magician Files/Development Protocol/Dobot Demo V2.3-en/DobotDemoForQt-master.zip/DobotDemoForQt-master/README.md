# DobotDemoForQt

DobotDemoForQt is the demo of Qt package dynamic library files.

This document describes the secondary development environment building and demo  codes, frameworks, and systems, aiming to help secondary developer to understand common API of Dobot Magician and build development environment quickly.

<div align=center>

<img src="images/qtdemo.png" width="500" height="350" />

</div>

## Project Description

Please download Qt5.6. If you use MSVC compiler, the lib file should be loaded (Add DobotDll.lib to the directory that DobotDll.dll is stored). While if you use MingGW complier, this is not required.

The three function modules in Figure indicate jogging, getting attitude information and implementing playback in PTP mode respectively.

<div align=center>

<img src="images/ui.png" width="500" height="500" />

</div>

## Code Description

- Connect to Dobot Magician and check whether the connection is successful.

```c++
    if (!connectStatus) {
        char fwType[1024];
        char version[1024];
        float time = 0;
        if (ConnectDobot(0, 115200, fwType, version, &time) != DobotConnect_NoError) {
            QMessageBox::information(this, tr("error"), tr("Connect dobot error!!!"), QMessageBox::Ok);
            return;
        }
        connectStatus = true;
        refreshBtn();
        initDobot();

        QTimer *getPoseTimer = findChild<QTimer *>("getPoseTimer");
        getPoseTimer->start(200);
        qDebug() << "connect success!!!";
    } else {
        QTimer *getPoseTimer = findChild<QTimer *>("getPoseTimer");
        getPoseTimer->stop();
        connectStatus = false;
        refreshBtn();
        DisconnectDobot();
    }
}
```

- Get the serial number of Dobot Magician.

```C++
    char deviceSN[64];
    qInfo() << "enter get device sn";
    GetDeviceSN(deviceSN, 64);
    qInfo() << "return from get device sn";
    ui->deviceSNLabel->setText(deviceSN);
```

- Get the Dobot Magician name.

```C++
    char deviceName[64];
    GetDeviceName(deviceName, 64);
    ui->DeviceNameLabel->setText(deviceName);
```

- Get the version information of Dobot Magician.

```C++
    uint8_t majorVersion, minorVersion, revision, hwVersion;
    GetDeviceVersion(&majorVersion, &minorVersion, &revision, &hwVersion);
    ui->DeviceInfoLabel->setText(QString::number(majorVersion) + "." + QString::number(minorVersion) + "." + QString::number(revision) + "." + QString::number(hwVersion));
```

- Set the offset of the end effector.

```C++
    EndEffectorParams endEffectorParams;
    memset(&endEffectorParams, 0, sizeof(endEffectorParams));
    endEffectorParams.xBias = 71.6f;
    SetEndEffectorParams(&endEffectorParams, false, NULL);
```

- Set the speed and acceleration of joint coordinate axis when jogging.

```C++
    JOGJointParams jogJointParams;
    for (int i = 0; i < 4; i++) {
        jogJointParams.velocity[i] = 100;
        jogJointParams.acceleration[i] = 100;
    }
    SetJOGJointParams(&jogJointParams, false, NULL);
```

- Set the speed and acceleration of Cartesian coordinate axis when jogging.

```C++
    JOGCoordinateParams jogCoordinateParams;
    for (int i = 0; i < 4; i++) {
        jogCoordinateParams.velocity[i] = 100;
        jogCoordinateParams.acceleration[i] = 100;
    }
    SetJOGCoordinateParams(&jogCoordinateParams, false, NULL);
```

- Set the speed ratio and acceleration ratio when playback. The default value is 50%. If not set, the default value will be used.

```C++
    JOGCommonParams jogCommonParams;
    jogCommonParams.velocityRatio = 50;
    jogCommonParams.accelerationRatio = 50;
    SetJOGCommonParams(&jogCommonParams, false, NULL);
```

- Set the speed and acceleration of joint coordinate axis when playback.

```C++
    PTPJointParams ptpJointParams;
    for (int i = 0; i < 4; i++) {
        ptpJointParams.velocity[i] = 100;
        ptpJointParams.acceleration[i] = 100;
    }
    SetPTPJointParams(&ptpJointParams, false, NULL);
```

- Set the speed and acceleration of Cartesian coordinate axis when playback.

```C++
    PTPCoordinateParams ptpCoordinateParams;
    ptpCoordinateParams.xyzVelocity = 100;
    ptpCoordinateParams.xyzAcceleration = 100;
    ptpCoordinateParams.rVelocity = 100;
    ptpCoordinateParams.rAcceleration = 100;
    SetPTPCoordinateParams(&ptpCoordinateParams, false, NULL);
```

- Set the lifting height and the maximum lifting height in JUMP mode.

```C++
    PTPJumpParams ptpJumpParams;
    ptpJumpParams.jumpHeight = 20;
    ptpJumpParams.zLimit = 150;
    SetPTPJumpParams(&ptpJumpParams, false, NULL);
```

- Jog Dobot Magician

```C++
    JOGCmd jogCmd;
    jogCmd.isJoint = ui->teachMode->currentIndex() == 0;
    jogCmd.cmd = index + 1;
    while (SetJOGCmd(&jogCmd, false, NULL) != DobotCommunicate_NoError) {
    }
```

- Set the starting point and the end point to make Dobot Magician move in PTP mode.

```C++
    PTPCmd ptpCmd;
    ptpCmd.ptpMode = PTPMOVJXYZMode;
    ptpCmd.x = ui->xPTPEdit->text().toFloat();
    ptpCmd.y = ui->yPTPEdit->text().toFloat();
    ptpCmd.z = ui->zPTPEdit->text().toFloat();
    ptpCmd.r = ui->rPTPEdit->text().toFloat();

    while (SetPTPCmd(&ptpCmd, true, NULL) != DobotCommunicate_NoError) {
    }
```

## Usage

- Use a 32-bit compiler
- Connect the Dobot Magician
- Ui control Dobot
