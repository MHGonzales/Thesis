# MagicianDll

## Introduction

Magiciandll is the source code and precompiled file for the DLL dynamic link library.

## Usage

1. The source code uses the Qt 5.6 development environment.
2. Developers in https://download.qt.io/archive/qt/5.6/5.6.0/, please download the QT version and install the suitable for their system.
3. If your project needs to work with the qyqt library, use the Qt version with the MSVC compiler and compile the Dobot dynamic link library with MSVC.

## License

Apache License2.0

