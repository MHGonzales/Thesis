## Magician Demo for Android

* 该项目由两个module构成
    
1. magicianbluetoothkits 是基本的蓝牙工具库，里面包含了对DobotMessage的封装
2. appDemo 是一个调用magcianbluetoothkits的库的demo