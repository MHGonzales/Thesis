package co.dobot.magicain.message;

import co.dobot.magicain.message.cmd.CMDParams;

/**
 * Created by x on 2018/5/17.
 */

public interface DobotMessageInterface {
    byte getCommandID();
    boolean isQueue();
    byte[] getParams();
    void setWriteMode(boolean isWrite);
    void setQueueMode(boolean isQueue);

    void cmdGetPose();
    void cmdSetPose(CMDParams.Pose pose);
    void cmdResetPose(CMDParams.ResetPose resetPose);
    void cmdGetKinematics();
    void cmdGetHomeParams();
    void cmdSetHomeParams(CMDParams.HomeParams homeParams);
    void cmdSetHomeCmd(CMDParams.HomeCmd homeCmd);
    void cmdSetHomeCmdQueue(CMDParams.HomeCmd homeCmd);
    void cmdHome();
    void cmdGetHHTTrigeMode();
    void cmdSetHHTTrigeMode(CMDParams.HHTTrigMode trigMode);
    void cmdJog(CMDParams.JOGCmd jogCmd);
    void cmdJOGcoordinate(CMDParams.JOGCmdCoordinate cmdCoordinate);
    void cmdJOGCommonVelocityRatio(float velocityRatio, float accelerationRatio);
    void cmdGetJOGCommonParams();
    void cmdSetJOGCommonParams(CMDParams.JOGCommonParams params);
    void cmdGetJOGCoordinateParams(CMDParams.JOGCmdCoordinateParams coordinateParams);
    void cmdGetPTPCoordinateParams();
    void cmdSetPTPCoordinateParams(CMDParams.PTPCoordinateParams ptpCoordinateParams);
    void cmdGetCPParams();
    void cmdSetCPParams(CMDParams.CPParams params);
    void cmdSetEndEffectorParams(CMDParams.EndEffectorParams params);
    void cmdGetEndEffectorParams();
    void cmdSetSuctionCupControlEnable(boolean controlEnable, boolean isSucked);
    void cmdGetSuctionCupOutput();
    void cmdSetGripperControlEnable(boolean controlEnable, boolean grip);
    void cmdGetGripper();
    void cmdSetLaser(boolean isOn, boolean isQueue);
    void cmdGetLaser();
    void cmdPTP(CMDParams.PTPCmd ptpCmd);
    void cmdCP(CMDParams.CPCmd cpCmd);
    void cmdCPLE(CMDParams.CPCmd cpCmd);
    void cmdGetDeviceWithL();
    void cmdSetDeviceWithLOn(boolean isOn);
    void cmdGetPoseL();
    void cmdSetDeviceWithL(CMDParams.WithL l);
    void cmdGetPTPLParams();
    void cmdSetPTPLParams(CMDParams.PTPLParams params, boolean isQueue);
    void cmdSetPTPL(CMDParams.PTPLCmd ptplCmd);
    void cmdSetIOMultiplexing(CMDParams.IOMultiplexing multiplexing, boolean isQueue);
    void cmdGetIOMultiplexing(CMDParams.IOMultiplexing multiplexing);
    void cmdSetIODO(CMDParams.IODO iodo, boolean isQueue);
    void cmdGetIODO(CMDParams.IODO iodo);
    void cmdSetIOPWM(CMDParams.IOPWM iopwm, boolean isQueue);
    void cmdGetIOPWM(CMDParams.IOPWM iopwm);
    void cmdGetIODI(CMDParams.IODI iodi);
    void cmdGetIOADC(CMDParams.IOADC ioadc);
    void cmdClearQueue();
    void cmdStartQueue();
    void cmdStopQueue();
    void cmdForceStopQueue();
    void cmdQueueCurrentIndex();
    void cmdQueueLeftSpace();
}
