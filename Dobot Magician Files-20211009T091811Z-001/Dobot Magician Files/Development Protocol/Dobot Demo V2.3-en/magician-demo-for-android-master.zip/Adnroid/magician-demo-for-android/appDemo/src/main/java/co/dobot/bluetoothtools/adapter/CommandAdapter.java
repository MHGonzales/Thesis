package co.dobot.bluetoothtools.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import co.dobot.bluetoothtools.R;


/**
 * Created by x on 2018/1/20.
 */

public class CommandAdapter extends RecyclerView.Adapter<CommandAdapter.CommandViewHolder>{
    Context context;
    CommandListener listener;
    public final static String[] cmdStr=new String[]{"CMD_GetPose","CMD_ptpcmds","CMD_QUEUE","CMD_JOG","CMD_EIO"};

    public CommandAdapter(Context context,CommandListener listener) {
        this.context = context;
        this.listener = listener;
    }

    @Override
    public CommandViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        CommandViewHolder holder= new CommandViewHolder(LayoutInflater.from(context)
                .inflate(R.layout.content_command_list,parent,false));
        return holder;
    }

    @Override
    public void onBindViewHolder(CommandViewHolder holder, final int position) {
        holder.command.setText(cmdStr[position]);
        holder.command.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                        listener.OnCommandSelect(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return cmdStr.length;
    }

    public class CommandViewHolder extends RecyclerView.ViewHolder{
        TextView command;
        public CommandViewHolder(View itemView) {
            super(itemView);
            command=(TextView)itemView.findViewById(R.id.command_list_text);
        }
    }

    public interface CommandListener{
        void OnCommandSelect(int position);
    }
}
