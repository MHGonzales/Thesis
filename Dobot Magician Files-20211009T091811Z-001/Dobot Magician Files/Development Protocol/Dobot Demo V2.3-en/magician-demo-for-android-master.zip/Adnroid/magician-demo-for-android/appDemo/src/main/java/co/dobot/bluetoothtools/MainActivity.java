package co.dobot.bluetoothtools;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashSet;

import co.dobot.bluetoothtools.adapter.CommandAdapter;
import co.dobot.bluetoothtools.adapter.DeviceListAdapter;
import co.dobot.magicain.client.BaseMessageClient;
import co.dobot.magicain.client.ClientCallback;
import co.dobot.magicain.client.DobotMessageClient;
import co.dobot.magicain.message.DobotMessage;
import co.dobot.magicain.message.base.MessageCallback;
import co.dobot.magicain.message.base.BaseMessage;
import co.dobot.magicain.message.cmd.CMDParams;

import static co.dobot.magicain.message.cmd.CMDParams.PTPMode.MOVE_L;

public class MainActivity extends AppCompatActivity {
    private String TAG = "BLE_TEST_MAIN";
    HashSet<BluetoothDevice> list = new HashSet<>();
    DeviceListAdapter adapter;
    RecyclerView deviceList;
    RecyclerView commandList;
    LinearLayout commandParams;
    Handler handler = new Handler();
    TextView[] textViews;
    EditText[] editTexts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        requestPermission();
        deviceList = (RecyclerView) findViewById(R.id.device_list_View);
        deviceList.setLayoutManager(new LinearLayoutManager(this));
        adapter = new DeviceListAdapter(MainActivity.this, list);
        deviceList.setAdapter(adapter);
        commandList = (RecyclerView) findViewById(R.id.command_list);
        commandList.setLayoutManager(new LinearLayoutManager(this));
        commandList.setAdapter(commandAdapter);
        commandParams = (LinearLayout) findViewById(R.id.command_layout);

        findViewById(R.id.button_send).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    //MessageClient.Instance().setFilterName("");
                    DobotMessageClient.Instance().startFindDevice(30);
                } catch (NullPointerException e) {
                    if (e.getMessage().equals("BleAdapter Can't Use")) {
                        Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                        startActivityForResult(enableBtIntent, 1001);
                    }
                }
            }
        });


        DobotMessageClient.Instance().createBLEKits(this);
        DobotMessageClient.Instance().setFilterName("WH-BLE");
        DobotMessageClient.Instance().setFilterName("100");
        DobotMessageClient.Instance().setScanType(BaseMessageClient.ScanType.FIND_AND_CONNECT_FIRST);
    }

    @Override
    protected void onResume() {
        super.onResume();

        DobotMessageClient.Instance().addSearchDeviceCallback(new ClientCallback.SearchDeviceCallback() {
            @Override
            public void didFindAvailableDevice(BluetoothDevice device) {
                list.add(device);
                adapter.setDevices(list);
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        adapter.notifyDataSetChanged();
                    }
                });
            }

            @Override
            public void FindDeviceTimeout() {

            }

        });

        DobotMessageClient.Instance().addConnectCallback(new ClientCallback.DeviceConnectCallback() {
            @Override
            public void didConnect() {
                adapter.setDialogDismiss();
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivity.this, "connect success", Toast.LENGTH_SHORT).show();
                        findViewById(R.id.main_command_layout).setVisibility(View.VISIBLE);
                        findViewById(R.id.main_device_list).setVisibility(View.GONE);
                        findViewById(R.id.main_disconnect).setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                // MessageClient.Instance().setConnectType(ConnectType.CONNECT_NORMAL);
                                DobotMessageClient.Instance().disconnect();
                            }
                        });


                    }
                });
            }

            @Override
            public void didDisConnect() {
                adapter.setDialogDismiss();
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivity.this, "connect fail", Toast.LENGTH_SHORT).show();
                        findViewById(R.id.main_command_layout).setVisibility(View.GONE);
                        findViewById(R.id.main_device_list).setVisibility(View.VISIBLE);
                    }
                });
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1001 && resultCode == RESULT_OK) {
            try {
                DobotMessageClient.Instance().startFindDevice(30);
            } catch (NullPointerException e) {
                if (e.getMessage().equals("BleAdapter Can't Use")) {
                    Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                    startActivityForResult(enableBtIntent, 1001);
                }
            }
        }
    }

    private void requestPermission() {
        Log.d(TAG, "requestPermission");
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.BLUETOOTH) != PackageManager.PERMISSION_GRANTED) { //表示未授权时
            //进行授权
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.BLUETOOTH}, 1);
        }

        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.BLUETOOTH_ADMIN) != PackageManager.PERMISSION_GRANTED) { //表示未授权时
            //进行授权
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.BLUETOOTH_ADMIN}, 2);
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, 3);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            Log.d(TAG, "code:" + requestCode + "permission granted!");
            //做下面该做的事
        } else {
            Log.d(TAG, "code:" + requestCode + " no permission,granted fail");
        }
    }

    boolean isCoordinate = true;
    CMDParams.JOGCmdMode jogCmdMode;
    Button[] buttons;
    Button button;
    CommandAdapter commandAdapter = new CommandAdapter(this, new CommandAdapter.CommandListener() {
        @Override
        public void OnCommandSelect(int position) {
            commandParams.removeAllViews();
            textViews = null;
            editTexts = null;
            buttons = null;
            {
                button = new Button(MainActivity.this);
                button.setText("Send");
                switch (position) {
                    case 0:
                        textViews = new TextView[1];
                        textViews[0] = new TextView(MainActivity.this);
                        textViews[0].setText("Pose:");
                        commandParams.addView(textViews[0]);
                        button.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                DobotMessage poseMessage = new DobotMessage();
                                poseMessage.cmdGetPose();
                                poseMessage.setCallback(new MessageCallback() {
                                    @Override
                                    public void onMsgReply(MsgState state, BaseMessage msg) {
                                        System.out.println("on state:"+state);
                                        DobotMessage message = (DobotMessage) msg;
                                        final CMDParams.Pose pose = new CMDParams.Pose();
                                        pose.initDataByBytes(message.getParams());
                                        handler.post(new Runnable() {
                                            @Override
                                            public void run() {
                                                textViews[0].setText("Pose x:" + pose.x + " y:" + pose.y + " z:" + pose.z + " r:" + pose.r);
                                            }
                                        });
                                    }
                                });
                                DobotMessageClient.Instance().sendMessage(poseMessage);
                            }
                        });
                        commandParams.addView(button);
                        break;
                    case 1:
                        textViews = new TextView[1];
                        textViews[0] = new TextView(MainActivity.this);
                        textViews[0].setText("PTP Mode:");
                        commandParams.addView(textViews[0]);
                        button.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                DobotMessage clearMessage = new DobotMessage();
                                clearMessage.cmdClearQueue();
                                DobotMessageClient.Instance().sendMessage(clearMessage);
                                DobotMessage startQueue = new DobotMessage();
                                startQueue.cmdStartQueue();
                                DobotMessageClient.Instance().sendMessage(startQueue);
                                CMDParams.PTPCmd ptpCmd1 = new CMDParams.PTPCmd();
                                ptpCmd1.ptpMode = MOVE_L;
                                ptpCmd1.x = 250;
                                ptpCmd1.y = 20;
                                ptpCmd1.z = 0;
                                ptpCmd1.r = 0;
                                CMDParams.PTPCmd ptpCmd2 = new CMDParams.PTPCmd(MOVE_L, 250, -20, 0, 0);
                                CMDParams.PTPCmd ptpCmd3 = new CMDParams.PTPCmd(MOVE_L, 200, -20, 0, 0);
                                CMDParams.PTPCmd ptpCmd4 = new CMDParams.PTPCmd(MOVE_L, 200, 20, 0, 0);
                                int count = 60;

                                CMDParams.PTPCmd[] ptpCmds = new CMDParams.PTPCmd[]{
                                        ptpCmd1, ptpCmd2, ptpCmd3, ptpCmd4
                                };

                                for (int i = 0; i < count; i++) {
                                    DobotMessage message = new DobotMessage();
                                    message.cmdPTP(ptpCmds[i % 4]);

                                    DobotMessageClient.Instance().sendMessage(message);
                                }

                            }
                        });
                        commandParams.addView(button);
                        break;
                    case 2:
                        buttons = new Button[3];
                        buttons[0] = new Button(MainActivity.this);
                        buttons[0].setText("start queue");
                        buttons[0].setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                DobotMessage startQueue = new DobotMessage();
                                startQueue.cmdStartQueue();
                                DobotMessageClient.Instance().sendMessage(startQueue);
                            }
                        });
                        buttons[1] = new Button(MainActivity.this);
                        buttons[1].setText("force stop queue");
                        buttons[1].setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                DobotMessage stopQueue = new DobotMessage();
                                stopQueue.cmdStopQueue();
                                DobotMessageClient.Instance().sendMessage(stopQueue);
                            }
                        });
                        buttons[2] = new Button(MainActivity.this);
                        buttons[2].setText("clear queue");
                        buttons[2].setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                DobotMessage clearQueue = new DobotMessage();
                                clearQueue.cmdClearQueue();
                                DobotMessageClient.Instance().sendMessage(clearQueue);
                            }
                        });
                        commandParams.addView(buttons[0]);
                        commandParams.addView(buttons[1]);
                        commandParams.addView(buttons[2]);
                        break;

                    case 3:
                        buttons = new Button[5];
                        buttons[0] = new Button(MainActivity.this);
                        buttons[1] = new Button(MainActivity.this);
                        buttons[2] = new Button(MainActivity.this);
                        buttons[3] = new Button(MainActivity.this);
                        buttons[4] = new Button(MainActivity.this);
                        buttons[0].setText("x+");
                        buttons[1].setText("x-");
                        buttons[2].setText("y+");
                        buttons[3].setText("y-");
                        buttons[4].setText("stop");
                        final Switch sw = new Switch(MainActivity.this);
                        sw.setText("coordinate");
                        sw.setChecked(true);
                        isCoordinate = true;
                        jogCmdMode= CMDParams.JOGCmdMode.COORDINATE;
                        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                            @Override
                            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                                isCoordinate = isChecked;
                                if (isCoordinate)
                                    jogCmdMode= CMDParams.JOGCmdMode.COORDINATE;
                                else
                                    jogCmdMode= CMDParams.JOGCmdMode.JOINT;
                                if (sw.isChecked()) {
                                    buttons[0].setText("x+");
                                    buttons[1].setText("x-");
                                    buttons[2].setText("y+");
                                    buttons[3].setText("y-");
                                    sw.setText("coordinate");
                                } else {
                                    sw.setText("joint");
                                    buttons[0].setText("j1+");
                                    buttons[1].setText("j1-");
                                    buttons[2].setText("j2+");
                                    buttons[3].setText("j2-");
                                }
                            }
                        });

                        buttons[0].setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                CMDParams.JOGCmd jogCmd=new CMDParams.JOGCmd();
                                jogCmd.initDataByEnum(jogCmdMode, CMDParams.JOGCmdCoordinate.X_PLUS);
                                DobotMessage message=new DobotMessage();
                                message.cmdJog(jogCmd);
                                DobotMessageClient.Instance().sendMessage(message);
                            }
                        });

                        DobotMessage message=new DobotMessage();
                        message.cmdQueueCurrentIndex();
                        message.setCallback(new MessageCallback() {
                            @Override
                            public void onMsgReply(MsgState msgState, BaseMessage baseMessage) {
                                if (msgState==MsgState.MSG_REPLY)
                                {
                                    DobotMessage dobotMessage= (DobotMessage) baseMessage;
                                    byte[] params=dobotMessage.getParams();
                                    //method: trans bytes to long
                                    //the communication protocol define the larger byte is in the bytes array tail
                                    long index = 0;
                                    for (int i = 7; i >=0;i--) {
                                        index <<= 8;
                                        index |= (params[i] & 0xff);
                                    }
                                    Log.i(TAG,"current index:"+index);
                                }
                            }
                        });
                        buttons[1].setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                CMDParams.JOGCmd jogCmd=new CMDParams.JOGCmd();
                                jogCmd.initDataByEnum(jogCmdMode, CMDParams.JOGCmdCoordinate.X_MINUS);
                                DobotMessage message=new DobotMessage();
                                message.cmdJog(jogCmd);
                                DobotMessageClient.Instance().sendMessage(message);
                            }
                        });
                        buttons[2].setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                CMDParams.JOGCmd jogCmd=new CMDParams.JOGCmd();
                                jogCmd.initDataByEnum(jogCmdMode, CMDParams.JOGCmdCoordinate.Y_PLUS);
                                DobotMessage message=new DobotMessage();
                                message.cmdJog(jogCmd);
                                DobotMessageClient.Instance().sendMessage(message);
                            }
                        });

                        buttons[3].setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                CMDParams.JOGCmd jogCmd=new CMDParams.JOGCmd();
                                jogCmd.initDataByEnum(jogCmdMode, CMDParams.JOGCmdCoordinate.Y_MINUS);
                                DobotMessage message=new DobotMessage();
                                message.cmdJog(jogCmd);
                                DobotMessageClient.Instance().sendMessage(message);
                            }
                        });
                        buttons[4].setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                CMDParams.JOGCmd jogCmd=new CMDParams.JOGCmd();
                                jogCmd.initDataByEnum(jogCmdMode, CMDParams.JOGCmdCoordinate.STOP);
                                DobotMessage message=new DobotMessage();
                                message.cmdJog(jogCmd);
                                DobotMessageClient.Instance().sendMessage(message);
                            }
                        });
                        commandParams.addView(sw);
                        commandParams.addView(buttons[0]);
                        commandParams.addView(buttons[1]);
                        commandParams.addView(buttons[2]);
                        commandParams.addView(buttons[3]);
                        commandParams.addView(buttons[4]);
                        break;
                    case 4:
                        buttons = new Button[3];
                        textViews=new TextView[1];
                        buttons[0] = new Button(MainActivity.this);
                        buttons[1] = new Button(MainActivity.this);
                        buttons[2] = new Button(MainActivity.this);
                        textViews[0]=new TextView(MainActivity.this);
                        textViews[0].setText("params:");
                        buttons[0].setText("setEIO");
                        buttons[1].setText("stopEIO");
                        buttons[2].setText("getEIO");
                        buttons[0].setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                CMDParams.IOMultiplexing ioMultiplexing=new CMDParams.IOMultiplexing();
                                ioMultiplexing.address=0x01;
                                ioMultiplexing.multiplex= CMDParams.IOFunction.DO.getValue();
                                DobotMessage message=new DobotMessage();
                                message.cmdSetIOMultiplexing(ioMultiplexing,false);
                                message.setCallback(new MessageCallback() {
                                    @Override
                                    public void onMsgReply(MsgState state, BaseMessage msg) {
                                        final CMDParams.IOMultiplexing ioMultiplexing=new CMDParams.IOMultiplexing();
                                        ioMultiplexing.initDataByBytes(((DobotMessage) msg).getParams());
                                        handler.post(new Runnable() {
                                            @Override
                                            public void run() {
                                                textViews[0].setText("address:"+ioMultiplexing.address+" multiplex:"+ioMultiplexing.multiplex);
                                            }
                                        });
                                    }
                                });
                                DobotMessageClient.Instance().sendMessage(message);
                            }
                        });
                        buttons[1].setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                CMDParams.IOMultiplexing ioMultiplexing=new CMDParams.IOMultiplexing();
                                ioMultiplexing.address=0x01;
                                ioMultiplexing.multiplex= CMDParams.IOFunction.DUMMY.getValue();
                                DobotMessage message=new DobotMessage();
                                message.cmdSetIOMultiplexing(ioMultiplexing,false);
                                message.setCallback(new MessageCallback() {
                                    @Override
                                    public void onMsgReply(MsgState state, BaseMessage msg) {
                                        final CMDParams.IOMultiplexing ioMultiplexing=new CMDParams.IOMultiplexing();
                                        ioMultiplexing.initDataByBytes(((DobotMessage) msg).getParams());
                                        handler.post(new Runnable() {
                                            @Override
                                            public void run() {
                                                textViews[0].setText("address:"+ioMultiplexing.address+" multiplex:"+ioMultiplexing.multiplex);
                                            }
                                        });
                                    }
                                });
                                DobotMessageClient.Instance().sendMessage(message);
                            }
                        });
                        buttons[2].setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                CMDParams.IOMultiplexing ioMultiplexing=new CMDParams.IOMultiplexing();
                                ioMultiplexing.address=0x01;
                                ioMultiplexing.multiplex= CMDParams.IOFunction.DUMMY.getValue();
                                DobotMessage message=new DobotMessage();
                                message.cmdGetIOMultiplexing(ioMultiplexing);
                                message.setCallback(new MessageCallback() {
                                    @Override
                                    public void onMsgReply(MsgState state, BaseMessage msg) {
                                        final CMDParams.IOMultiplexing ioMultiplexing=new CMDParams.IOMultiplexing();
                                        ioMultiplexing.initDataByBytes(((DobotMessage) msg).getParams());
                                        handler.post(new Runnable() {
                                            @Override
                                            public void run() {
                                                textViews[0].setText("address:"+ioMultiplexing.address+" multiplex:"+ioMultiplexing.multiplex);
                                            }
                                        });
                                    }
                                });
                                DobotMessageClient.Instance().sendMessage(message);
                            }
                        });
                        commandParams.addView(textViews[0]);
                        commandParams.addView(buttons[0]);
                        commandParams.addView(buttons[1]);
                        commandParams.addView(buttons[2]);

                }
            }
        }
    });


}
