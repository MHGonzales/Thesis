package CPlusDll;

import java.util.ArrayList;
import java.util.List;

import com.sun.jna.Library;  
import com.sun.jna.Native;
import com.sun.jna.Structure;
import com.sun.jna.ptr.FloatByReference;
import com.sun.jna.ptr.LongByReference;
/* 此文件定义了将在主程序中被使用的类 将dll库中使用的类型封装为对应的java类型 
 * This file define the classes that will be used in the main program. It encapsulates c-structures as corresponding Java class 
 */
public interface DobotDll extends Library 
{  
	DobotDll instance = (DobotDll) Native.loadLibrary("DobotDll",  DobotDll.class);  
    
    public static class Pose extends Structure
    {
    	//如果Pose只是作为api的参数或返回值则不需要另外声明传递的Pose为ByReference或ByValue 因为JNA将根据c中的定义自行转换  类中的类型声明顺序必须与提供的c头文件相符合
    	//Notice that if the structre is only to be used in api functions as arguments or return value there is no need to include this two line
    	//The declaration must be in the same order as such in the original c header file DobotDllM1.h
    	/*
    	public static class ByReference extends Pose implements Structure.ByReference{}
    	public static class ByValue extends Pose implements Structure.ByValue{}
    	*/
        public float x;
        public float y;
        public float z;
        public float r;
        public float[] jointAngle = new float[4];;

		@Override
		//此步骤为必要步骤 JNA现要求编写时手动规定类中的fields顺序   
		//The getFieldOrder() function must be defined and return a string list represent the proper order of the fields defined in current structure
		protected List<String> getFieldOrder()
		{
			List<String> a = new ArrayList<String>();  
			a.add("x");  
			a.add("y"); 
			a.add("z"); 
			a.add("r"); 
			a.add("jointAngle");
			return a;  
		}
		//初始化实例时需声明内存按照1byte对齐对应c中头文件的pragma pack(1) 注：部分类型缺少此初始化函数 因为结构本身已经按照1byte对齐
		//You must initialize the encapsulated class with 1 byte memory alignment corresponding to pragma pack(1) in the c header file. 
		//NOTE:some classes defined in this module miss this initialization function because their memory layouts are naturally aligned to one byte.
		public Pose()
		{
			this.setAlignType(ALIGN_NONE);
		}
    };
    
    public static class EndEffectorParams extends Structure
    {
        public float xBias;
        public float yBias;
        public float zBias;
		@Override
		protected List<String> getFieldOrder() {
			List<String> a = new ArrayList<String>();  
		       a.add("xBias");  
		       a.add("yBias"); 
		       a.add("zBias"); 
		       return a;  
		}
    };
    
    public enum JOG
    {
        JogIdle,
        JogAPPressed,
        JogANPressed,
        JogBPPressed,
        JogBNPressed,
        JogCPPressed,
        JogCNPressed,
        JogDPPressed,
        JogDNPressed,
        JogEPPressed,
        JogENPressed
    };
    
    public static class JOGCmd extends Structure
    {
    	public JOGCmd() {
		    setAlignType(Structure.ALIGN_NONE);
		}
        public byte isJoint;
        public byte cmd;
		@Override
		protected List<String> getFieldOrder() {
			List<String> a = new ArrayList<String>();  
		       a.add("isJoint");  
		       a.add("cmd"); 
		       return a;  
		}
    };
    
    public static class JOGJointParams extends Structure
    {
        public float[] velocity = new float[4];
        public float[] acceleration = new float[4];
		@Override
		protected List<String> getFieldOrder() {
			List<String> a = new ArrayList<String>();  
		       a.add("velocity");  
		       a.add("acceleration"); 
		       return a;  
		}
    };
    
    public static class JOGCoordinateParams extends Structure
    {
        public float[] velocity = new float[4];
        public float[] acceleration = new float[4];
		@Override
		protected List<String> getFieldOrder() {
			List<String> a = new ArrayList<String>();  
		       a.add("velocity");  
		       a.add("acceleration"); 
		       return a;  
		}
    };
    
    public static class JOGCommonParams extends Structure
    {
        public float velocityRatio;
        public float accelerationRatio;
		@Override
		protected List<String> getFieldOrder() {
			List<String> a = new ArrayList<String>();  
		       a.add("velocityRatio");  
		       a.add("accelerationRatio"); 
		       return a;  
		}
    };
    
    public enum PTPMode {
        PTPJUMPXYZMode,
        PTPMOVJXYZMode,
        PTPMOVLXYZMode,

        PTPJUMPANGLEMode,
        PTPMOVJANGLEMode,
        PTPMOVLANGLEMode,

        PTPMOVJXYZINCMode,
        PTPMOVLXYZINCMode
    };
    
    public static class PTPCmd extends Structure
    {
    	public PTPCmd() {
		    setAlignType(Structure.ALIGN_NONE);
		}
    	/*
    	public static class ByReference extends PTPCmd implements Structure.ByReference { }  
        public static class ByValue extends PTPCmd implements Structure.ByValue{ }
        */
        public byte ptpMode;
        public float x;
        public float y;
        public float z;
        public float r;
		@Override
		protected List<String> getFieldOrder() {
			List<String> a = new ArrayList<String>();  
		       a.add("ptpMode");  
		       a.add("x"); 
		       a.add("y"); 
		       a.add("z"); 
		       a.add("r"); 
		       return a;  
		}
    };
    
    public static class PTPJointParams extends Structure
    {
        public float[] velocity = new float[4];
        public float[] acceleration = new float[4];
		@Override
		protected List<String> getFieldOrder() {
			List<String> a = new ArrayList<String>();  
		       a.add("velocity");  
		       a.add("acceleration"); 
		       return a;  
		}
    };
    
    public static class PTPCoordinateParams extends Structure
    {
        public float xyzVelocity;
        public float rVelocity;
        public float xyzAcceleration;
        public float rAcceleration;
		@Override
		protected List<String> getFieldOrder() {
			List<String> a = new ArrayList<String>();  
		       a.add("xyzVelocity");  
		       a.add("rVelocity"); 
		       a.add("xyzAcceleration");  
		       a.add("rAcceleration"); 
		       return a;  
		}
    };
    
    public static class PTPJumpParams extends Structure
    {
        public float jumpHeight;
        public float zLimit;
		@Override
		protected List<String> getFieldOrder() {
			List<String> a = new ArrayList<String>();  
		       a.add("jumpHeight");  
		       a.add("zLimit"); 
		       return a;  
		}
    };

    public enum DobotResult
    {
        DobotConnect_NoError,
        DobotConnect_NotFound,
        DobotConnect_Occupied
    };
    //c中的char* 对应 java中的byte【】
    int ConnectDobot(char portName, int baudrate, byte[] fwtype, byte[] version, FloatByReference time);
    void DisconnectDobot();
    void SetCmdTimeout(int cmdTimeout);
    int SetQueuedCmdClear();
    int SetQueuedCmdStartExec();
    int SetEndEffectorParams(EndEffectorParams endEffectorParams, boolean isQueued, LongByReference queuedCmdIndex);
    int DobotExec();

    // Pose
    int GetPose(Pose pose);
    
    // Jog functions
    // C中的float对应java中的long
    // Float in c correspond to long in java
    int SetJOGCmd(JOGCmd jogCmd, boolean isQueued, LongByReference ueuedCmdIndex);
    int SetJOGJointParams(JOGJointParams jogJointParams, boolean isQueued, LongByReference ueuedCmdIndex);
    int SetJOGCoordinateParams(JOGCoordinateParams jogCoordinateParams, boolean isQueued, LongByReference ueuedCmdIndex);
    int SetJOGCommonParams(JOGCommonParams jogCommonParams, boolean isQueued, LongByReference ueuedCmdIndex);

    // Playback functions
    int SetPTPCmd(PTPCmd ptpCmd, boolean isQueued, LongByReference queuedCmdIndex);
    int SetPTPJointParams(PTPJointParams ptpJointParams, boolean isQueued, LongByReference ueuedCmdIndex);
    int SetPTPCoordinateParams(PTPCoordinateParams ptpCoordinateParams, boolean isQueued, LongByReference ueuedCmdIndex);
    int SetPTPJumpParams(PTPJumpParams ptpJumpParams, boolean isQueued, LongByReference ueuedCmdIndex);
}