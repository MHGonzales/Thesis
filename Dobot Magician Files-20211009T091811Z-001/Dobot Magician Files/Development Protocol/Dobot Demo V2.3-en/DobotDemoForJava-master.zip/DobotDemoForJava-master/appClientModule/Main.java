import java.util.Timer;
import java.util.TimerTask;

import CPlusDll.DobotDll;
import CPlusDll.DobotDll.*;

import com.sun.jna.ptr.FloatByReference;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.LongByReference;

public class Main
{
	public static void main(String[] args) {
		try { 
			
			Main app = new Main();
			app.Start();
			
			LongByReference ib = new LongByReference();
			/*
			JOGCmd test = new JOGCmd();
			test.isJoint = 1;
	    	while(true)
	    	{
	    		try{
	    			test.cmd = 1;
	    			DobotDll.instance.SetJOGCmd(test, false, ib);
		    		Thread.sleep(500);
		            test.cmd = 0;
		            DobotDll.instance.SetJOGCmd(test, false, ib);
		    		Thread.sleep(1000);
		            test.cmd = 2;
		            DobotDll.instance.SetJOGCmd(test, false, ib);
		    		Thread.sleep(500);
		            test.cmd = 0;
		            DobotDll.instance.SetJOGCmd(test, false, ib);
		    		Thread.sleep(1000);
		    		
	    		} catch (Exception e) {  
	                e.printStackTrace();  
	            }
	    	}*/
	    	
	    	while(true)
	    	{
	    		try{
	    			PTPCmd ptpCmd = new PTPCmd();
	    			ptpCmd.ptpMode = 0;
	    			ptpCmd.x = 260;
	    			ptpCmd.y = 0;
	    			ptpCmd.z = 50;
	    			ptpCmd.r = 0;
	    			DobotDll.instance.SetPTPCmd(ptpCmd, true, ib);
		    		//Thread.sleep(200);
		    		
		    		ptpCmd.ptpMode = 0;
	    			ptpCmd.x = 220;
	    			ptpCmd.y = 0;
	    			ptpCmd.z = 80;
	    			ptpCmd.r = 0;
	    			DobotDll.instance.SetPTPCmd(ptpCmd, true, ib);	    		
		    		//Thread.sleep(200);
		    		
	    		} catch (Exception e) {  
	                e.printStackTrace();  
	            }
	    	}
			//DobotDll.instance.DisconnectDobot();
		} catch (Exception e) {  
            e.printStackTrace();  
        }
	}

	private void Start() {
		byte[] fwtype = new byte[128];
		byte[] version = new byte[128];
		FloatByReference time = new FloatByReference(0);
		DobotResult ret = DobotResult.values()[DobotDll.instance.ConnectDobot((char)0, 115200, fwtype, version, time)];
        // ��ʼ����
        if (ret == DobotResult.DobotConnect_NotFound || ret == DobotResult.DobotConnect_Occupied)
        {
            Msg("Connect error, code:" + ret.name());
            return;
        }
        Msg("connect success code:" + ret.name());
        
	    StartDobot();

	    StartGetStatus();
	}
	/* (non-Java-doc)
	 * @see java.lang.Object#Object()
	 */
	public Main() {
		super();
	}

	private void StartDobot() {
		//此方程初始化Dobot的运动参数例如运动时的速度与加速度
		//This function initializes common parameters of Dobot host such as velocity and acceleration in motion
		LongByReference ib = new LongByReference();
        EndEffectorParams endEffectorParams = new EndEffectorParams();
        endEffectorParams.xBias = 71.6f;
        endEffectorParams.yBias = 0;
        endEffectorParams.zBias = 0;
        DobotDll.instance.SetEndEffectorParams(endEffectorParams, false, ib);
        JOGJointParams jogJointParams = new JOGJointParams();
        for(int i = 0; i < 4; i++) {
        	jogJointParams.velocity[i] = 200;
        	jogJointParams.acceleration[i] = 200;
        }
        DobotDll.instance.SetJOGJointParams(jogJointParams, false, ib);
        
        JOGCoordinateParams jogCoordinateParams = new JOGCoordinateParams();
        for(int i = 0; i < 4; i++) {
        	jogCoordinateParams.velocity[i] = 200;
        	jogCoordinateParams.acceleration[i] = 200;
        }
        DobotDll.instance.SetJOGCoordinateParams(jogCoordinateParams, false, ib);
        
        JOGCommonParams jogCommonParams = new JOGCommonParams();
        jogCommonParams.velocityRatio = 50;
        jogCommonParams.accelerationRatio = 50;
        DobotDll.instance.SetJOGCommonParams(jogCommonParams, false, ib);
        
        PTPJointParams ptpJointParams = new PTPJointParams();
        for(int i = 0; i < 4; i++) {
        	ptpJointParams.velocity[i] = 200;
        	ptpJointParams.acceleration[i] = 200;
        }
        DobotDll.instance.SetPTPJointParams(ptpJointParams, false, ib);
        
        PTPCoordinateParams ptpCoordinateParams = new PTPCoordinateParams();
        ptpCoordinateParams.xyzVelocity = 200;
        ptpCoordinateParams.xyzAcceleration = 200;
        ptpCoordinateParams.rVelocity = 200;
        ptpCoordinateParams.rAcceleration = 200;
        DobotDll.instance.SetPTPCoordinateParams(ptpCoordinateParams, false, ib);
        
        PTPJumpParams ptpJumpParams = new PTPJumpParams();
        ptpJumpParams.jumpHeight = 20;
        ptpJumpParams.zLimit = 180;
        DobotDll.instance.SetPTPJumpParams(ptpJumpParams, false, ib);
        
        //设置指令超时时间 清空队列中剩余的指令 并开始执行队列 注:有两种方法可以执行队列 1.先调用api函数setQueuedCmdStartExec() 然后将指令插入队列中 2.先将指令插入到队列 再调用函数开始执行队列
        //Set timeout limit and start executing command queue. NOTE: There are two ways to execute the command queue.1.Call API function setQueueStartExec() first then queue command
        //2. Queue command then call the API function
        DobotDll.instance.SetCmdTimeout(3000);
        DobotDll.instance.SetQueuedCmdClear();
        DobotDll.instance.SetQueuedCmdStartExec();
	}
	
	private void StartGetStatus() {
		//此函数调用GetPose用于定时获得dobot的实时位置
		//This function call api function GetPose to get the real time pose of Dobot host periodically. 
		Timer timerPos = new Timer();
        timerPos.schedule(new TimerTask() {
            public void run() {
            	Pose pose = new Pose();
                DobotDll.instance.GetPose(pose);

                Msg("joint1Angle="+pose.jointAngle[0]+"  " 
                		+ "joint2Angle="+pose.jointAngle[1]+"  "
                		+ "joint3Angle="+pose.jointAngle[2]+"  "
                		+ "joint4Angle="+pose.jointAngle[3]+"  "
                		+ "x="+pose.x+"  "
                		+ "y="+pose.y+"  "
                		+ "z="+pose.z+"  "
                		+ "r="+pose.r+"  ");
            }
        }, 100, 500);//
	}
	
	private void Msg(String string) {
		System.out.println(string); 
	}
}