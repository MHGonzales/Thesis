# Demo-Magician-Qt-Multi

Demo-Magician-Qt-Multi is a QT demo that can be used to control multiple devices.


## Project Description

The DobotDll library in this demo is exclusively used for multi-control and cannot be used in 
other demos.

## Code Description

The codes of this demo are much same as that of QtDemo, but each API has one more parameter
(dobotId) to comfirm the ID number of Dobot Magician that has been connected, for multi-control.

- Connect to Dobot Magician and DLL will return the ID number of Dobot Magician that 
has been connected. For subsequent operations, you need to carry the ID number to 
specify Dobot Magician.

```c
if (!connectStatus) {
if (ConnectDobot(ui->lineEdit->text().toLatin1().data(),
115200, fwType, version, &dobotId) !=
DobotConnect_NoError)
{
QMessageBox::information(this, tr("error"),
tr("Connect dobot error!!!"),
QMessageBox::Ok);
return;
} }
qDebug() << "dobotId" << dobotId;
```

- Get the serial number of Dobot Magician.

```c++
char deviceSN[64];
GetDeviceSN(dobotId, deviceSN, sizeof(deviceSN));
ui->deviceSNLabel->setText(deviceSN);
```

- Get the Dobot Magician name.

```c
char deviceName[64];
GetDeviceName(dobotId, deviceName, sizeof(deviceName));
ui->DeviceNameLabel->setText(deviceName);
```

- Get the version information of Dobot Magician.

```c
uint8_t majorVersion, minorVersion, revision;
GetDeviceVersion(dobotId, &majorVersion, &minorVersion, &revision);
ui->DeviceInfoLabel->setText(QString::number(majorVersion) +
"." + QString::number(minorVersion) +
"." + QString::number(revision));
```

- Set the offset of the end effector.

```c
EndEffectorParams endEffectorParams;
memset(&endEffectorParams, 0, sizeof(endEffectorParams));
endEffectorParams.xBias = 71.6f;
SetEndEffectorParams(dobotId, &endEffectorParams, false, NULL);
```

- Set the speed and acceleration of joint coordinate axis when jogging.

```c
JOGJointParams jogJointParams;
for (int i = 0; i < 4; i++) {
jogJointParams.velocity[i] = 100;
jogJointParams.acceleration[i] = 100;
}
SetJOGJointParams(dobotId, &jogJointParams, false, NULL);
```

- Set the speed and acceleration of Cartesian coordinate axis when jogging.

```c
JOGCoordinateParams jogCoordinateParams;
for (int i = 0; i < 4; i++) {
jogCoordinateParams.velocity[i] = 100;
jogCoordinateParams.acceleration[i] = 100;
}
SetJOGCoordinateParams(dobotId, &jogCoordinateParams, false, NULL);
```

- Set the speed ratio and acceleration ratio when playback. The default value is 50%. If 
not set, the default value will be used.

```c
JOGCommonParams jogCommonParams;
jogCommonParams.velocityRatio = 50;
jogCommonParams.accelerationRatio = 50;
SetJOGCommonParams(dobotId, &jogCommonParams, false, NULL);
```

- Set the speed and acceleration of joint coordinate axis when playback.

```c
PTPJointParams ptpJointParams;
for (int i = 0; i < 4; i++) {
ptpJointParams.velocity[i] = 100;
ptpJointParams.acceleration[i] = 100;
}
SetPTPJointParams(dobotId, &ptpJointParams, false, NULL);
```

- Set the speed and acceleration of Cartesian coordinate axis when playback.

```c
PTPCoordinateParams ptpCoordinateParams;
ptpCoordinateParams.xyzVelocity = 100;
ptpCoordinateParams.xyzAcceleration = 100;
ptpCoordinateParams.rVelocity = 100;
ptpCoordinateParams.rAcceleration = 100;
SetPTPCoordinateParams(dobotId, &ptpCoordinateParams, false, NULL);
```

- Set the lifting height and the maximum lifting height in JUMP mode.

```c
PTPJumpParams ptpJumpParams;
ptpJumpParams.jumpHeight = 20;
ptpJumpParams.zLimit = 150;
SetPTPJumpParams(dobotId, &ptpJumpParams, false, NULL);
```

- Jog Dobot Magician.

```c
JOGCmd jogCmd;
jogCmd.isJoint = ui->teachMode->currentIndex() == 0;
jogCmd.cmd = index + 1;
while (SetJOGCmd(dobotId, &jogCmd, false, NULL) !=
DobotCommunicate_NoError)
{…}
```

- Get the attitude information of Dobot Magician.

```c
Pose pose;
while (GetPose(dobotId, &pose) != DobotCommunicate_NoError) {
}
ui->joint1Label->setText(QString::number(pose.jointAngle[0]));
ui->joint2Label->setText(QString::number(pose.jointAngle[1]));
ui->joint3Label->setText(QString::number(pose.jointAngle[2]));
ui->joint4Label->setText(QString::number(pose.jointAngle[3]));
ui->xLabel->setText(QString::number(pose.x));
ui->yLabel->setText(QString::number(pose.y));
ui->zLabel->setText(QString::number(pose.z));
ui->rLabel->setText(QString::number(pose.r));
```

- Set the starting point and the end point to make Dobot Magician move in PTP mode.

```c
PTPCmd ptpCmd;
ptpCmd.ptpMode = PTPMOVJXYZMode;
ptpCmd.x = ui->xPTPEdit->text().toFloat();
ptpCmd.y = ui->yPTPEdit->text().toFloat();
ptpCmd.z = ui->zPTPEdit->text().toFloat();
ptpCmd.r = ui->rPTPEdit->text().toFloat();
SetPTPCmd(dobotId, &ptpCmd, true, NULL);
```
## Usage

- Use WiFi module to connect multiple devices for debugging
